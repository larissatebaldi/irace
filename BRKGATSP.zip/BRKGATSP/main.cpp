#include <iostream>
#include "SampleDecoder.h"
#include "MTRand.h"
#include "BRKGA.h"

#include <sys/time.h>
#include "data.h"

struct timeval start, finish;
#define mtime (finish.tv_sec  - start.tv_sec) + (finish.tv_usec - start.tv_usec)/1000000.0

//C:\Users\Larissa\Documents\R\win-library\3.2\irace\tuning\BRKGA\instancia100.txt 1 1 0 2 0.3 0.1 0.7 1000
//C:\Users\Larissa\Documents\R\win-library\3.2\irace\tuning\BRKGA\Instancias\2000-21.tsp 1 1 0 2 0.3 0.1 0.7 1000

int main(int argc, char* argv[]) {
    if (argc <= 1 || argc > 11) {
        cout << "Usage: " << argv[0] << " <intance> <config_ID> <instance_ID> <seed> <multipPop> <pe> <pm> <rhoe> <MaxGeracao> " << endl;
        exit(-1);
    }

    string inst_name(argv[1]);
	data dat;
	dat.read(inst_name);
	cout << "Leitura ok" << endl;

    // inst_name = (argv[2] + "-c -" + argv[3]).c_str();

    const int SeedTime = atol(argv[4]);
    const int multip = atol(argv[5]);

    const double pe = atof(argv[6]);
    const double pm = atof(argv[7]);
    const double rhoe = atof(argv[8]);
    const int MAX_GENS = atof(argv[9]);




	const unsigned n = dat.N;		// size of chromosomes
	const unsigned p = multip*n;	// size of population
	// const double pe = 0.20;		// fraction of population to be the elite-set
	// const double pm = 0.10;		// fraction of population to be replaced by mutants
	// const double rhoe = 0.70;	// probability that offspring inherit an allele from elite parent
	const unsigned K = 3;		// number of independent populations
	const unsigned MAXT = 2;	// number of threads for parallel decoding


	SampleDecoder decoder;			// initialize the decoder

	const long unsigned rngSeed = SeedTime; //time(NULL);	// seed to the random number generator
	MTRand rng(rngSeed);				// initialize the random number generator

	// initialize the BRKGA-based heuristic
	BRKGA< SampleDecoder, MTRand > algorithm(dat, n, p, pe, pm, rhoe, decoder, rng, K, MAXT);

	unsigned generation = 0;		// current generation
	// const unsigned X_INTVL = 100;	// exchange best individuals at every 100 generations
	// const unsigned X_NUMBER = 2;	// exchange top 2 best
	// const unsigned MAX_GENS = 1000;	// run for 1000 gens

	gettimeofday(&start, NULL);

	do {
		algorithm.evolve(dat);	// evolve the population for one generation

		// if((++generation) % X_INTVL == 0) {
		// 	algorithm.exchangeElite(X_NUMBER);	// exchange top individuals
		// }
		std::cout << generation << std::endl;
		++generation;
	} while (generation < MAX_GENS);
	gettimeofday(&finish, NULL);

	std::cout << "Seed = " << rngSeed << std::endl;

	std::cout << "Total time = " << mtime << std::endl;

	// std::cout << "Best : " << algorithm.getBestFitness();
	std::cout << "Best " << algorithm.getBestFitness();


	// std::cout << "Best chromosome ";
	// std::vector< double > chromosome = algorithm.getBestChromosome();
	// for(int i = 0; i < chromosome.size(); ++i) {
	// 	std::cout << chromosome[i] << " \t ";
	// }
	// std::cout  << std::endl;

	return 0;
}
