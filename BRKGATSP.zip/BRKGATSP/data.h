#ifndef DADOS_H_
#define DADOS_H_

#include <iostream>
#include <fstream>
#include <string.h>
#include <math.h>
#include <vector>

using namespace std;

class data {
private:

protected:

public:
	typedef struct coord {
		double x;
		double y;
	} coord;


	//************ VARIAVEIS
	std::vector < std::vector <double> > cost;
	int N;


	//************ DISTANCIA
	double dist(double xa, double ya, double xb, double yb){
		return sqrt(pow((xb - xa),2) + pow((yb - ya),2));
	};


	/** Leitura dos dados */
	void read(std::string inst_name){
		// inst_name = "Instancias/" + pasta;
		std::ifstream arq(inst_name.c_str());
		if (!arq.is_open()){
			std::cout << "Error: The archive can't be open (board data)" << std::endl;
			exit(1);
		}

		arq.ignore(256,':');
		arq.ignore(256,':');
		arq.ignore(256,':');
		arq.ignore(256,':');

		arq >> N;
		// std::cout << N << std::endl;
		// getchar();

		std::vector <coord> Pontos;
		coord aux;
		aux.x = 0;
		aux.y = 0;

		for (int i = 0; i < N; i++){
			cost.push_back(std::vector <double> (N) );
			for (int j = 0; j < N; j++){
				cost[i][j] = 0;
			}
		}	

		arq.ignore(256,':');

		string lixo;
		arq >> lixo;		
		arq >> lixo;

		int lixoAux;

		for(int i = 0; i < N; i++){
			Pontos.push_back(aux);
			arq >> lixoAux;
			arq >> Pontos[i].x;
			arq >> Pontos[i].y;
		}	

		// for(int i = 0; i < N; i++){
		// 	std::cout << Pontos[i].x << " \t " << Pontos[i].y << std::endl;
		// }
		// getchar();

		//************ CUSTOS
		for(int i = 0; i < N; i++){
			for(int j = 0; j < N; j++){
				cost[i][j] = dist(Pontos[i].x, Pontos[i].y, Pontos[j].x, Pontos[j].y);
				//  std::cout << i << " " << j << " " << cost[i][j] << std::endl;
			}
		}
		// getchar();


	};


};

#endif

