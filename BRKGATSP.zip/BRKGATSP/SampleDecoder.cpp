/*
 * SampleDecoder.cpp
 *
 *  Created on: Jan 14, 2011
 *      Author: rtoso
 */

#include "SampleDecoder.h"
#include <iostream>
#include <stdio.h>

#include "data.h"

SampleDecoder::SampleDecoder() { }

SampleDecoder::~SampleDecoder() { }

// Runs in \Theta(n \log n):
double SampleDecoder::decode(data dat, const std::vector< double >& chromosome) const {
	std::vector< std::pair< double, unsigned > > ranking(chromosome.size());
	double myFitness = 0.0;

	for(unsigned i = 0; i < chromosome.size(); ++i) {
		ranking[i] = std::pair< double, unsigned >(chromosome[i], i);
	}
	// for(int i = 0; i < chromosome.size(); ++i) {
	// 	std::cout << "ranking " << i << " \t " << ranking[i].first << " \t " << ranking[i].second << std::endl;
	// }	


	// Here we sort 'permutation', which will then produce a permutation of [n] in pair::second:
	std::sort(ranking.begin(), ranking.end());
	// for(int i = 0; i < chromosome.size(); ++i) {
	// 	std::cout << "ranking after " << i << " \t " << ranking[i].first << " \t " << ranking[i].second << std::endl;
	// }


	for(unsigned i = 0; i < ranking.size()-1; ++i) {
		// std::cout << ranking[i].second << "\t" << ranking[i+1].second << std::endl;
		// std::cout << dat.cost[ranking[i].second][ranking[i+1].second] << std::endl;
		myFitness += dat.cost[ranking[i].second][ranking[i+1].second];
	}
	// std::cout << ranking[ranking.size()-1].second << "\t" << ranking[0].second << std::endl;
	// std::cout << dat.cost[ranking[ranking.size()-1].second][ranking[0].second] << std::endl;	
	myFitness += dat.cost[ranking[ranking.size()-1].second][ranking[0].second];
	

	// std::cout << myFitness << std::endl;	
	// getchar();	

	// sample fitness is the first allele
	return myFitness;//chromosome.front();
}
